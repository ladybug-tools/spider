#!/bin/bash

########################################################################################
##                                                                                    ##
## Radiance Workshop 2019 Tutorial                                                    ##
## BSDF GENERATION AND USE IN ANNUAL, MATRIX-BASED DAYLIGHT SIMULATIONS WITH RADIANCE ##
## 21 Aug. 2019, David Geisler-Moroder, Bartenbach GmbH                               ##
##                                                                                    ##
## Example script for generating BSDF from geometrical blind model                    ##
##                                                                                    ##
########################################################################################

nCPU=$( nproc )

sysname=blinds_20deg_noGlazing
sysperiod=0.052
systhick=0.0657238
samp=10000
#samp=100 # to show...

# convert *.obj into *.rad
obj2rad ${sysname}.obj > ${sysname}.rad

# generate Klems BSDF
date
echo "Running genBSDF on ${sysname} for Klems..."
genBSDF -c ${samp} -n ${nCPU} +b +f -geom meter -dim -${sysperiod} ${sysperiod} -${sysperiod} ${sysperiod} -${systhick} 0 ${sysname}.mat ${sysname}.rad > ${sysname}_Klems.xml

date
echo "done."
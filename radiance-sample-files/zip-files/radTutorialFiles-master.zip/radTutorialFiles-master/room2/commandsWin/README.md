An empty place holder for the path room2\commandsWin
Additional notes maybe added later.
An empty place holder for the path room2\results
Additional notes maybe added later.
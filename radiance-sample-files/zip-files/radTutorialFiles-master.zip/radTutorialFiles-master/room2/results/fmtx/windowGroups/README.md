An empty place holder for the path room2\results\fmtx\windowGroups
Additional notes maybe added later.
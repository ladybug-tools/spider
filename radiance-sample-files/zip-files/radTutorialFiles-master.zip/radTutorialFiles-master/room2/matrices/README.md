An empty place holder for the path room2\matrices
Additional notes maybe added later.
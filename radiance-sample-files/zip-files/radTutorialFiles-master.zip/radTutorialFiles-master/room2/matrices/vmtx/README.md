An empty place holder for the path room2\matrices\vmtx
Additional notes maybe added later.
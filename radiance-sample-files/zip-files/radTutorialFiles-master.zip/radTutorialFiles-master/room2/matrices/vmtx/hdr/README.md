An empty place holder for the path room2\matrices\vmtx\hdr
Additional notes maybe added later.
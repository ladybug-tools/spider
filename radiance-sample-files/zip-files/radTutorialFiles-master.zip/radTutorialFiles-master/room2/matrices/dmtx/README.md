An empty place holder for the path room2\matrices\dmtx
Additional notes maybe added later.
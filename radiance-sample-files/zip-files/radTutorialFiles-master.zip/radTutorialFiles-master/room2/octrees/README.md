An empty place holder for the path room2\octrees
Additional notes maybe added later.
An empty place holder for the path room2\skies
Additional notes maybe added later.
An empty place holder for the path room\matrices\dcd\hdr
Additional notes maybe added later.
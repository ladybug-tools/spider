An empty place holder for the path room\matrices\dc\hdr
Additional notes maybe added later.
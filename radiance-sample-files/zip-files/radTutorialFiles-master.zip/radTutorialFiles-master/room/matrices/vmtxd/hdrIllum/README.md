An empty place holder for the path room\matrices\vmtxd\hdrIllum
Additional notes maybe added later.
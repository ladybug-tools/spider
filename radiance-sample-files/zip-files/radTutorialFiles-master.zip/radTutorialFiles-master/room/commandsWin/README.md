An empty place holder for the path room\commandsWin
Additional notes maybe added later.
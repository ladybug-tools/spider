An empty place holder for the path room\results\5ph\cds\hdr
Additional notes maybe added later.
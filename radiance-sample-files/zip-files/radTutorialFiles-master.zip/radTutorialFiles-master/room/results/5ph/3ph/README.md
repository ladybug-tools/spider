An empty place holder for the path room\results\5ph\3ph
Additional notes maybe added later.
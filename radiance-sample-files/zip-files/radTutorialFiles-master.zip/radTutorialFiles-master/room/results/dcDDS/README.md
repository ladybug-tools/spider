An empty place holder for the path room\results\dcDDS
Additional notes maybe added later.
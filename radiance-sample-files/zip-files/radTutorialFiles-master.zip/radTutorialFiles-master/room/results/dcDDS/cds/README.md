An empty place holder for the path room\results\dcDDS\cds
Additional notes maybe added later.
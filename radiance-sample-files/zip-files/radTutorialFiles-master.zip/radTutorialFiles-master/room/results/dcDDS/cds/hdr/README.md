An empty place holder for the path room\results\dcDDS\cds\hdr
Additional notes maybe added later.
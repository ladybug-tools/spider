An empty place holder for the path room\results\6ph\fmtx\hdr
Additional notes maybe added later.
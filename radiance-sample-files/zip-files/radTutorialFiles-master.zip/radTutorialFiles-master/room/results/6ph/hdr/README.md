An empty place holder for the path room\results\6ph\hdr
Additional notes maybe added later.
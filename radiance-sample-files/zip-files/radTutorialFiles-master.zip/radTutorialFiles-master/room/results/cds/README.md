An empty place holder for the path room\results\cds
Additional notes maybe added later.
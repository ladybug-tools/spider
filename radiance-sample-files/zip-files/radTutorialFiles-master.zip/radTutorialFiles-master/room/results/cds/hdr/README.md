An empty place holder for the path room\results\cds\hdr
Additional notes maybe added later.
An empty place holder for the path room\results\dc
Additional notes maybe added later.
An empty place holder for the path room\results\fmtx
Additional notes maybe added later.
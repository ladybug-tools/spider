An empty place holder for the path room\octrees
Additional notes maybe added later.
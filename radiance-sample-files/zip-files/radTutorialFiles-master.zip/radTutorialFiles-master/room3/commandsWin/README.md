An empty place holder for the path room3\commandsWin
Additional notes maybe added later.
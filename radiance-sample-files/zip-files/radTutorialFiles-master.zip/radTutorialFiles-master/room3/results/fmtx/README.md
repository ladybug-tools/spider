An empty place holder for the path room3/results/fmtx
Additional notes maybe added later.
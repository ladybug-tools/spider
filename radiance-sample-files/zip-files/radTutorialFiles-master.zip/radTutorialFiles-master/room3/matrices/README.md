An empty place holder for the path room3\matrices
Additional notes maybe added later.
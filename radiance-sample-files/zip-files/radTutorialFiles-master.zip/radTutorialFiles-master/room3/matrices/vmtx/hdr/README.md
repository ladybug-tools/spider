An empty place holder for the path room3\matrices\vmtx\hdr
Additional notes maybe added later.
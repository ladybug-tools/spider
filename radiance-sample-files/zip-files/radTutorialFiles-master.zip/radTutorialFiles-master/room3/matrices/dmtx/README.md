An empty place holder for the path room3\matrices\dmtx
Additional notes maybe added later.
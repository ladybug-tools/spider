An empty place holder for the path room3\skies
Additional notes maybe added later.
An empty place holder for the path room3\octrees
Additional notes maybe added later.